package com.example.webappseguridad.Beans;

public class NivelDeUrgencia {
    private int idNivelDeUrgencia;
    private String nombre;

    public int getIdNivelDeUrgencia() {
        return idNivelDeUrgencia;
    }

    public void setIdNivelDeUrgencia(int idNivelDeUrgencia) {
        this.idNivelDeUrgencia = idNivelDeUrgencia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
