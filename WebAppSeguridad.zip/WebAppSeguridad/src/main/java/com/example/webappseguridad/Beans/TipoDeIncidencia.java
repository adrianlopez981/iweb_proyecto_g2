package com.example.webappseguridad.Beans;

public class TipoDeIncidencia {
    private int idTipoDeIncidencia;
    private String nombre;

    public int getIdTipoDeIncidencia() {
        return idTipoDeIncidencia;
    }

    public void setIdTipoDeIncidencia(int idTipoDeIncidencia) {
        this.idTipoDeIncidencia = idTipoDeIncidencia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
