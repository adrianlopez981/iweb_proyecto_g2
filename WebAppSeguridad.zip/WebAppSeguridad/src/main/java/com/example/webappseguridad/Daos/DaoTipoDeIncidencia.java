package com.example.webappseguridad.Daos;

import com.example.webappseguridad.Beans.TipoDeIncidencia;

import java.sql.*;
import java.util.ArrayList;

public class DaoTipoDeIncidencia {
    public ArrayList<TipoDeIncidencia> obtenerListaTipoDeIncidencias(){
        ArrayList<TipoDeIncidencia> listaTipoDeIncidencias = new ArrayList<>();

        //Parametros de Conexion

        String user = "root";
        String password = "root";
        String url = "jdbc:mysql://127.0.0.1:3306/bdgigacontrol";

        //Conexion a base de datos

        String sql = "select * from tipoincidencia";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            //Registro de Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            while (rs.next()) {
                TipoDeIncidencia tipoDeIncidencia = new TipoDeIncidencia();
                tipoDeIncidencia.setIdTipoDeIncidencia(rs.getInt(1));
                tipoDeIncidencia.setNombre(rs.getString(2));
                listaTipoDeIncidencias.add(tipoDeIncidencia);
            }


        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }

        return listaTipoDeIncidencias;
    }
}
